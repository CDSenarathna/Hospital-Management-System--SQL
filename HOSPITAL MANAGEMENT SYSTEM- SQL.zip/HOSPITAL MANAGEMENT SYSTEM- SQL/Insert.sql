INSERT INTO PATIENT
VALUES
('P071','vishwa de silva','Male','Ratnapura','1977-11-01','O+','076-4664693','Cancer','DOC 003 ','R 0022 ','B022');


insert into In_patient 
values
('I0011','P071','2022-10-29',Null);


insert into Bill
values
('B011',690,1500,1500,'mobile transfer','2022-04-05','Paid');

insert into Test
values
('TST016','Whole Blood',2500.00,'Lab006');

insert into Patient_treatments
values
('P071','Hormone therapy','DOC 010');
